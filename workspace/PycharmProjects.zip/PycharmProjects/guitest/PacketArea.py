import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk
from GtkUtil import bold_label
from GtkUtil import create_box


class PacketArea(Gtk.Box):
    def __init__(self):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.VERTICAL, spacing=5)

        title = bold_label("<big><u>Packet Area</u></big>")
        title.set_xalign(0.03)
        self.pack_start(title, False, False, 0)

        buttons = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        remove = Gtk.Button("Remove")
        buttons.pack_end(remove, False, False, 0)
        clear = Gtk.Button("Clear")
        buttons.pack_end(clear, False, False, 0)
        box = create_box([PacketInfo(), buttons])
        box.set_spacing(15)
        self.pack_start(box, False, False, 0)


class PacketInfo(Gtk.Box):
    def __init__(self):
        Gtk.Box.__init__(self, orientation=Gtk.Orientation.VERTICAL)

        b1 = create_box([Gtk.CheckButton(), bold_label("Frame 718: frame, eth, ip, tcp"), bold_label("\t\t\t\t\t\t\t\t\t\t"
                                                                                                     "\t\t\t\t\t\t\t\t\t\t   Size")])
        b2 = create_box([Gtk.CheckButton(), Gtk.Label("\tFrame 718: 74 bytes on wire (592 bits), 74 bytes captured "
                                                 "(592 bits) on interface 0"), Gtk.Label("\t\t\t\t\t\t\t\t74")])
        b3 = create_box([Gtk.CheckButton(), Gtk.Label("\tEthernet II, Src: Elitegro_dd:12:cd (00:19:21:dd:12:cd), "
                                                 "Dst: Broadcom_de:ad:05 (00:10:18:de:ad:05)"), Gtk.Label("\t\t\t\t 20")])
        b4 = create_box([Gtk.CheckButton(), Gtk.Label("\tInternet Control Message Protocol"), Gtk.Label("\t\t\t\t\t\t\t\t\t"
                                                                                                        "\t\t\t\t\t\t\t\t\t      25")])
        b5 = create_box([Gtk.CheckButton(), Gtk.Label("\tTransmission Control Protocl, Src Port: 55394 (55394), "
                                                 "Dst Port: 80 (80), Seq: 0, Len: 0"), Gtk.Label("\t\t\t\t\t\t\t  25")])
        b6 = create_box([Gtk.CheckButton(), bold_label("Frame 767: frame, eth, ip, tcp"), bold_label(" ")])
        b7 = create_box([Gtk.CheckButton(), bold_label("Frame 768: frame, eth, ip, tcp"), bold_label(" ")])
        b8 = create_box([Gtk.CheckButton(), bold_label("Frame 769: frame, eth, ip, tcp, http"), bold_label(" ")])

        self.pack_start(b1, False, False, 0)
        self.pack_start(b2, False, False, 0)
        self.pack_start(b3, False, False, 0)
        self.pack_start(b4, False, False, 0)
        self.pack_start(b5, False, False, 0)
        self.pack_start(b6, False, False, 0)
        self.pack_start(b7, False, False, 0)
        self.pack_start(b8, False, False, 0)
