import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from GtkUtil import bold_label
import ast


class FieldArea(Gtk.Box):

    fieldinfo = None

    def __init__(self):
        Gtk.Grid.__init__(self, spacing=10, orientation=Gtk.Orientation.VERTICAL)

        title = Gtk.Label()
        title.set_markup("<u><b><big> Field Area </big></b></u>")
        title.set_xalign(0.05)
        self.pack_start(title, False, False, 0)

        self.fieldinfo = FieldInfoTable()
        self.pack_start(self.fieldinfo, False, False, 0)

        box = Gtk.Box(spacing=15)
        allfields = Gtk.CheckButton("Select all fields")
        box.pack_start(allfields, False, False, 0)
        field_label = Gtk.Label()
        field_label.set_markup("<small>Field Name, Showname, Value, and Length are editable fields</small>")
        box.pack_start(field_label, False, False, 0)
        self.pack_end(box, False, False, 0)

    def get_pairs(self, pair=True):
        return self.fieldinfo.get_pairs(pair)


class FieldInfoTable(Gtk.Grid):

    fields = []
    check_buttons = []

    def __init__(self):
        Gtk.Grid.__init__(self, column_homogeneous=False, row_spacing=10)

        headers = [Gtk.Label(""), bold_label("  Field Name "), bold_label("    Showname    "),
                   bold_label("Size"), bold_label("Position"), bold_label("Show"),
                   bold_label("Value"), bold_label("Entropy")]
        self.fill_row(0, headers)
        self.update_fields("field_default.txt")

    def fill_row(self, row, items):
        for index, item in enumerate(items):
            self.attach(item, index, row, 1, 1)

    def update_fields(self, filename):
        f = open(filename, "r")

        row = 1
        line = f.readline().strip('\n')
        while line:
            dict_field = ast.literal_eval(line)
            self.fields.append(dict_field)
            self.build_field_row(row, dict_field)
            line = f.readline().strip('\n')
            row = row + 1
        f.close()

    def build_field_row(self, row, dict_field):
        check_button = Gtk.CheckButton()
        self.check_buttons.append(check_button)

        fieldname = Gtk.Entry()
        fieldname.set_text(dict_field['fieldname'])

        showname = Gtk.Entry()
        showname.set_text(dict_field['showname'])

        size = Gtk.Entry(width_chars=5)
        size.set_text(dict_field['size'])

        position = Gtk.Label(dict_field['position'])
        show = Gtk.Label(dict_field['show'])

        value = Gtk.Entry(width_chars=5)
        value.set_text(dict_field['value'])

        entropy = Gtk.Label(dict_field['entropy'])

        items = [check_button, fieldname, showname, size,
                 position, show, value, entropy]
        self.fill_row(row, items)

    def get_pairs(self, pair=True):
        pairs = []
        for i, button in enumerate(self.check_buttons):
            if button.get_active():
                if pair:
                    value = self.fields[i]['value']
                else:
                    value = ""
                pairs.append((self.fields[i]['fieldname'], value))
        return pairs


