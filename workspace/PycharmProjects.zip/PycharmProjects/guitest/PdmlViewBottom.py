import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from FieldArea import FieldArea
from MessageTypeArea import MessageTypeArea


class PdmlViewBottom(Gtk.Grid):

    fieldarea = FieldArea()
    messagetypearea = MessageTypeArea()

    def __init__(self):
        Gtk.Grid.__init__(self, column_spacing=5, row_homogeneous=False, column_homogeneous=False)
        self.attach(self.fieldarea, 0, 0, 1, 7)

        buttons = Gtk.Box(spacing=15, orientation=Gtk.Orientation.VERTICAL)
        self.attach(buttons, 1, 4, 1, 1)

        plus_img = Gtk.Image.new_from_file("plus_arrow.png")
        plus_button = Gtk.Button()
        plus_button.connect("clicked", self.on_click_plus_button)
        plus_button.add(plus_img)

        minus_img = Gtk.Image.new_from_file("minus_arrow.png")
        minus_button = Gtk.Button()
        minus_button.add(minus_img)

        buttons.pack_start(plus_button, False, False, 0)
        buttons.pack_start(minus_button, False, False, 0)

        self.attach(self.messagetypearea, 2, 0, 1, 7)

    def on_click_plus_button(self, button):
        pairs = self.fieldarea.get_pairs(self.messagetypearea.is_pairs_checked())
        self.messagetypearea.insert_pairs(pairs)

