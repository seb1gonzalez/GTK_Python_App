import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
import GtkUtil


class PCAPWindow(Gtk.Window):
    def __init__(self):
        Gtk.Window.__init__(self, title="PCAP")
        self.set_default_size(400, 220)

        box = Gtk.Box(spacing=6, orientation=Gtk.Orientation.VERTICAL)
        instructions = GtkUtil.bold_label("\nOpen a PCAP File\n")
        box.pack_start(instructions, False, False, 0)

        pcap_name = Gtk.Entry(width_chars=15)
        browse_pcap = Gtk.Button("Browse")
        box.pack_start(GtkUtil.create_box([GtkUtil.bold_label("\t\tPCAP Name"),
                                           pcap_name,
                                           browse_pcap]), False, False, 0)

        dissector_name = Gtk.Entry(width_chars=15)
        browse_dissector = Gtk.Button("Browse")
        box.pack_start(GtkUtil.create_box([GtkUtil.bold_label("\tDissector Name"),
                                           dissector_name,
                                           browse_dissector]), False, False, 0)

        convert = Gtk.Button("Convert to PDML")
        cancel = Gtk.Button("Cancel")
        box.pack_end(GtkUtil.create_box([cancel, convert], False), False, False, 0)

        self.add(box)


def run_popwindow():
    win = PCAPWindow()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
