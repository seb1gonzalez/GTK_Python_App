import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from PdmlViewBottom import PdmlViewBottom
from FilterArea import FilterAreaWindow
from PacketArea import PacketArea
from GtkUtil import create_box
from GtkUtil import create_small_label


class PDMLView(Gtk.Box):

    packet_area = None
    filter_area = None

    def __init__(self):
        Gtk.Box.__init__(self, spacing=20, orientation=Gtk.Orientation.VERTICAL)
        self.set_homogeneous(False)

        head = Gtk.HeaderBar()
        head.props.title = "PDML View"
        self.add(head)

        self.pack_start(self.create_pdml_control_view(), False, False, 0)
        self.filter_area = FilterAreaWindow()
        self.packet_area = PacketArea()
        self.pack_start(self.filter_area, False, False, 0)
        self.pack_start(self.packet_area, False, False, 0)
        self.pack_start(PdmlViewBottom(), False, False, 0)

    def create_pdml_control_view(self):
        new_name_entry = Gtk.Entry(width_chars=35)

        save_as_new_button = Gtk.Button()
        save_as_new_button.add(create_small_label("Save as New\nPDML State"))

        save_current_button = Gtk.Button()
        save_current_button.add(create_small_label("Save Current\nPDML State"))

        close_current_button = Gtk.Button()
        close_current_button.add(create_small_label("Close Current\nPDML State"))

        delete_current_button = Gtk.Button()
        delete_current_button.add(create_small_label("Delete Current\nPDML State"))

        rename_entry = Gtk.Entry(width_chars=35)

        rename_button = Gtk.Button()
        rename_button.add(create_small_label("Delete Current\nPDML State"))

        box = create_box([Gtk.Label(" "),new_name_entry, save_as_new_button, save_current_button,  # REMOVE LATER
                          close_current_button, delete_current_button, rename_entry, rename_button, Gtk.Label(" ")])
        box.set_spacing(5)
        return box


